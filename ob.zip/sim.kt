package com.example.keotam

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

// ===== ACTIVITY CHÍNH =====
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val tv = TextView(this).apply {
            text = "🎯 KÉO TÂM LÊN ĐẦU\n\n1. Bật trợ năng\n2. Cấp quyền vẽ đè\n3. Mở game bật AIM"
            textSize = 20f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = android.view.Gravity.CENTER
            setBackgroundColor(0xFF1A1A2E.toInt())
        }
        setContentView(tv)

        // Mở cài đặt trợ năng
        startActivity(android.content.Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

        // Xin quyền Overlay
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            startActivity(android.content.Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:$packageName")
            ))
        }
        finish()
    }

    // ===== DỊCH VỤ TRỢ NĂNG =====
    class AimService : AccessibilityService() {
        private var overlay: android.view.View? = null
        private val handler = Handler(Looper.getMainLooper())
        private var isActive = false
        private lateinit var wm: WindowManager

        override fun onServiceConnected() {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                if (Build.VERSION.SDK_INT >= 26)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            )
            params.gravity = android.view.Gravity.TOP or android.view.Gravity.END
            params.x = 16; params.y = 200

            overlay = Button(this).apply {
                text = "🟢 BẬT"
                setBackgroundColor(0xFFF44336.toInt())
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 13f
                setOnClickListener {
                    isActive = !isActive
                    text = if (isActive) "🔴 TẮT" else "🟢 BẬT"
                    setBackgroundColor(if (isActive) 0xFF4CAF50.toInt() else 0xFFF44336.toInt())
                }
            }
            wm.addView(overlay, params)
            startLoop()
        }

        private fun startLoop() {
            handler.postDelayed(object : Runnable {
                override fun run() {
                    if (isActive) {
                        val randX = Random.nextInt(-10, 10)
                        val randY = Random.nextInt(-10, 10)
                        val path = Path()
                        path.moveTo(540f + randX, 960f + randY)
                        path.lineTo(540f + randX + Random.nextInt(-8, 8), 870f + randY)
                        dispatchGesture(
                            GestureDescription.Builder()
                                .addStroke(GestureDescription.StrokeDescription(path, 0, 12))
                                .build(), null, null
                        )
                    }
                    handler.postDelayed(this, 25)
                }
            }, 500)
        }

        override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
        override fun onInterrupt() {}
        override fun onDestroy() {
            overlay?.let { wm.removeView(it) }
            handler.removeCallbacksAndMessages(null)
        }
    }
}